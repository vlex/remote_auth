#!/usr/bin/python
print "Content-Type: text/html\n\n"

print	"<html>\n"
print	"<a href=\"./RemoteAuth.py\"><h2>Acceso a vlex</h2></a>\n"
print	"</html>\n"